

<div>&nbsp;</div>
<section class="bg-contectmain">
    <div class="container">
        <div class="row"><!---Start row--->
            <div class="col-lg-12 bg-contect">
                <div>&nbsp;</div>
                <p class="feel-free">Feel Free to Contact us</p>
                <p class="feel-free-number">
                    <center><a
                            href="tel:18555700146"><span
                                class="bell fa fa-bell"></span>
                            1-855-570-0146</a></center>
                </p>
            </div>
        </div>
    </div><!---End row--->
</section>

<div class="row bg-footer"><!--Start row-->
    <div class="container col-ftr">
        <div class="col-lg-12">
            <div>&nbsp;</div>
            <p class="footer-logo"><a
                    href="https://www.topairlinerules.com/"><img
                        src="https://www.topairlinerules.com/asset/image/Logo.png" alt="Logo"
                        class="logo"></a></p>
            <p class="footer-text">
                Top Airline Rules ensure security and transparency with
                some of the most popular airline policies, such as
                flight changes, cancellations, name changes, and
                reservations. These facilitate simple modifications to
                your air travel plans for ultimate comfort. We at Top
                Airline Rules promise to offer you reliable information
                that you can trust.
            </p>
        </div>
    </div><!--End container-->
</div><!--End row-->
<footer class="mb-2">
    <section class="footer-section">
        <div class="container"><!--container-->
            <div class="row">
                <div class="col-lg-12 footer-navigation ">


                    <div class="buttons">
                        <ul id="navMenus">
                            <li onclick="toggleVisibility('Menu1');"
                                class="btn active">Destinations</li>
                            <!--<li onclick="toggleVisibility('Menu2');" class="btn">Routes</li>-->
                            <li onclick="toggleVisibility('Menu3');"
                                class="btn">Legal Links</li>
                            <!--<li onclick="toggleVisibility('Menu4');" class="btn">Menu4</li>-->
                        </ul>
                    </div>


                </div>

                <div id="Menu1" class="Menu1">
                    <div class="container  ">
                        <div class="row justify-content-between">
                            <div class="col-lg-3 col-md-6 col-sm-6 mt-4 ">
                                <div class="footer__logo">
                                    <figure>
                                        <a href="https://www.topairlinerules.com/"><img src="https://www.topairlinerules.com/asset/image/Logo.png" class="img-responsive" alt="logo" width="150" height="45"></a>
                                    </figure>

                                </div>
                                <div class="footer_first_area mt-3">
                                    <div class="footer_inquery_area mb-3">

                                    </div>
                                    <div class="footer_inquery_area footer_icon_cont flex_prop">
                                        <div class="icon_footer flex_prop">
                                            <i class="fa fa-solid fa-envelope"></i>
                                        </div>
                                        <p class="mb-0"> <a href="mailto:support@topairlinerules.com" style="text-decoration: none;">support@topairlinerules.com</a></p>
                                    </div>
                                    <div class="footer_inquery_area footer_icon_cont flex_prop mt-3">
                                        <div class="icon_footer flex_prop">
                                            <i class="fa fa-solid fa-phone"></i>
                                        </div>
                                        <p class="mb-0"> <a href="tel:+1-855-570-0146" style="text-decoration: none;">+1-855-570-0146</a></p>
                                    </div>

                                    <div class="footer_inquery_area mt-3">
                                        <p class="des_title mb-2">Follow us on</p>
                                        <ul class="soical_icon_footer flex_prop_f">
                                            <li><a href="" aria-label="Facebook"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="https://x.com/topairline30540" target="_blank" aria-label="Twitter"><i class="fa fa-twitter-square"></i></a></li>
                                            <li><a href="" aria-label="Instagram"><i class="fa fa-instagram"></i></a></li>
                                            <li><a href="https://www.pinterest.com/topairlinerules/" target="_blank" aria-label="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6 mt-4 ">
                                <div class="footer_heading_area">
                                    <p class="footer_title">Name Change Policy</p>
                                </div>
                                <div class="footer_link_area mt-3">
                                    <ul>
                                        <li><a
                                                href="https://www.topairlinerules.com/alaska-airlines-name-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Alaska
                                                Airlines Name Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/delta-airlines-name-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Delta
                                                Airlines Name Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/hawaiian-airlines-name-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Hawaiian
                                                Airlines Name Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/jetblue-airlines-name-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> JetBlue
                                                Airlines Name Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/southwest-airlines-name-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Southwest
                                                Airlines Name Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/spirit-airlines-name-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Spirit
                                                Airlines Name Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/united-airlines-name-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> United
                                                Airlines Name Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/volaris-airlines-name-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Volaris
                                                Airlines Name Change Policy </a></li>

                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6 mt-4 ">
                                <div class="footer_heading_area">
                                    <p class="footer_title">Cancellation Policy</p>
                                </div>
                                <div class="footer_link_area mt-3">
                                    <ul>
                                        <li><a
                                                href="https://www.topairlinerules.com/alaska-airlines-cancellation-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Alaska
                                                Airlines Cancellation Policy</a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/delta-airlines-cancellation-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Delta
                                                Airlines Cancellation Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/hawaiian-airlines-cancellation-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Hawaiian
                                                Airlines Cancellation Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/jetblue-airlines-cancellation-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> JetBlue
                                                Airlines Cancellation Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/southwest-airlines-cancellation-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Southwest
                                                Airlines Cancellation Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/spirit-airlines-cancellation-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Spirit
                                                Airlines Cancellation Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/united-airlines-cancellation-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> United
                                                Airlines Cancellation Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/volaris-airlines-cancellation-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Volaris
                                                Airlines Cancellation Policy </a></li>

                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6 mt-4 ">
                                <div class="footer_heading_area">
                                    <p class="footer_title">Flight Change Policy</p>
                                </div>
                                <div class="footer_link_area mt-3">
                                    <ul>
                                        <li><a
                                                href="https://www.topairlinerules.com/alaska-airline-flight-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Alaska
                                                Airline Flight Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/delta-airline-flight-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Delta
                                                Airline Flight Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/hawaiian-airlines-flight-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Hawaiian
                                                Airlines Flight Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/jetblue-airline-flight-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> JetBlue
                                                Airline Flight Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/southwest-airlines-flight-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Southwest
                                                Airlines Flight Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/spirit-airlines-flight-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Spirit
                                                Airlines Flight Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/united-airlines-flight-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> United
                                                Airlines Flight Change Policy </a></li>
                                        <li><a
                                                href="https://www.topairlinerules.com/volaris-airlines-flight-change-policy"><i
                                                    class="fa fa-caret-right"
                                                    aria-hidden="true"></i> Volaris
                                                Airlines Flight Change Policy </a></li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div id="Menu2" style="display: none;" class="Menu2">

                    <div class="menu-left col-md-6">
                        <p class="footer-link">Routes</p>
                        <ul>
                            <li><a
                                    href="alaska-airline-flight-change-policy"><i
                                        class="fa fa-caret-right"
                                        aria-hidden="true"></i> </a></li>

                        </ul>
                    </div>
                    <div class="menu-centre col-md-6">
                        <p class="footer-link">Routes</p>
                        <ul>
                            <li><a
                                    href="alaska-airline-flight-change-policy"><i
                                        class="fa fa-caret-right"
                                        aria-hidden="true"></i> </a></li>

                        </ul>
                    </div>
                    <div class="menu-centre col-md-6">
                        <p class="footer-link">Routes</p>
                        <ul>
                            <li><a
                                    href="Alaska-Airline-Flight-Change-Policy"><i
                                        class="fa fa-caret-right"
                                        aria-hidden="true"></i> </a></li>

                        </ul>
                    </div>

                </div>

                <div id="Menu3" style="display: none;" class="Menu3">
                    <div class="menu-left col-md-6">
                        <p class="footer-link">Legal Links</p>
                        <ul>
                            <li><a href="https://www.topairlinerules.com/"><i
                                        class="fa fa-caret-right"
                                        aria-hidden="true"></i>
                                    Home</a></li>
                        </ul>
                    </div>
                    <div class="menu-centre col-md-6">
                        <p class="footer-link">Legal Links</p>
                        <ul>
                            <li><a href="https://www.topairlinerules.com/aboutus"><i
                                        class="fa fa-caret-right"
                                        aria-hidden="true"></i> About
                                    us</a></li>
                        </ul>
                    </div>
                    <div class="menu-centre col-md-6">
                        <p class="footer-link">Legal Links</p>
                        <ul>
                            <li><a href="https://www.topairlinerules.com/contactus"><i
                                        class="fa fa-caret-right"
                                        aria-hidden="true"></i> Contact
                                    us</a></li>
                        </ul>
                    </div>
                </div>
                <!--<div id="Menu4" style="display: none;" class="Menu4">
  
  <div class="menu-left col-md-6">
<p class="footer-link">Destinations</p>
<ul>
<li><a href="Alaska-Airline-Flight-Change-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Alaska Airlines Flight Change Policy</a></li>
<li><a href="Delta-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Delta Airlines Cancellation Policy</a></li>
<li><a href="Spirit-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Spirit Airlines Cancellation Policy</a></li>
<li><a href="United-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> United Airlines Cancellation Policy</a></li>
<li><a href="United-Airlines-Flight-Change-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> United Airlines Flight Change Policy</a></li>
<li><a href="Volaris-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Volaris Airlines Cancellation Policy</a></li>
</ul>
</div>
<div class="menu-centre col-md-6">
<p class="footer-link">Destinations</p>
<ul>
<li><a href="Alaska-Airline-Flight-Change-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Alaska Airlines Flight Change Policy</a></li>
<li><a href="Delta-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Delta Airlines Cancellation Policy</a></li>
<li><a href="Spirit-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Spirit Airlines Cancellation Policy</a></li>
<li><a href="United-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> United Airlines Cancellation Policy</a></li>
<li><a href="United-Airlines-Flight-Change-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> United Airlines Flight Change Policy</a></li>
<li><a href="Volaris-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Volaris Airlines Cancellation Policy</a></li>
</ul>
</div>
<div class="menu-centre col-md-6">
<p class="footer-link">Destinations</p>
<ul>
<li><a href="Alaska-Airline-Flight-Change-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Alaska Airlines Flight Change Policy</a></li>
<li><a href="Delta-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Delta Airlines Cancellation Policy</a></li>
<li><a href="Spirit-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Spirit Airlines Cancellation Policy</a></li>
<li><a href="United-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> United Airlines Cancellation Policy</a></li>
<li><a href="United-Airlines-Flight-Change-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> United Airlines Flight Change Policy</a></li>
<li><a href="Volaris-Airlines-Cancellation-Policy"><i class="fa fa-caret-right" aria-hidden="true"></i> Volaris Airlines Cancellation Policy</a></li>
</ul>
</div>
 </div>-->

            </div>
        </div><!--End container-->
    </section>
</footer>
<div class="copyright_area w-100 py-3">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12">
                <div class="copyright_left text-center pb-0">
                    <p class="text-light mb-0">Copyright © 2024 Top Airlines All Rights Reserved.</p>
                </div>
            </div>

        </div>
    </div>
</div>
<script>
    // Configuration object for options
    var options = {
        autoPlay: true, // Or false
        autoPlayInterval: 3000, // Autoplay interval in milliseconds
        swipeThreshold: 50, // Minimum swipe distance in pixels
    };
</script>
<script>
    var divs = ["Menu1", "Menu2", "Menu3", "Menu4"];
    var visibleDivId = null;

    function toggleVisibility(divId) {
        if (visibleDivId === divId) {
            //visibleDivId = null;
        } else {
            visibleDivId = divId;
        }
        hideNonVisibleDivs();
    }

    function hideNonVisibleDivs() {
        var i, divId, div;
        for (i = 0; i < divs.length; i++) {
            divId = divs[i];
            div = document.getElementById(divId);
            if (visibleDivId === divId) {
                div.style.display = "block";
            } else {
                div.style.display = "none";
            }
        }
    }
</script>
<script>
    $("#navMenus").on('click', 'li', function() {
        $("#navMenus li.active").removeClass("active");
        // adding classname 'active' to current click li 
        $(this).addClass("active");
    });
    $('.call_us_fixed').on('click', function() {
        $('.call_us_cont').toggle('.2', 'linear');
    });
</script>

<div class="modal  shadow-sm fade" id="flightloader" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content rounded-0">

            <div class="modal-body mb-3 ">
                <div class="text-center">

                    <h4>Please Wait...</h4>


                    <p>To get you all the results so you can compare the best options</p>

                    <div class="fw-bold text-center my-3 fs-3">
                        <p style="font-size:18px;font-weight:500" id="address"></p>
                    </div>
                    <div class="fw-bold text-center my-3 fs-3">
                        <h5 style="font-size:18px;font-weight:500" id="date"></h5>
                    </div>
                    <div class="fw-bold text-center my-3 fs-3">
                        <h5 style="font-size:18px;font-weight:500" id="class"></h5>
                    </div>
                    <div class="text-center mb-3 ">
                        <img src="asset/image/air_freight.gif" style="width:120px;" alt="" class="img-fluid">
                    </div>
                    <div class="support mb-4 ">
                        <h4 class="mb-4">Call Now for <span class="fs-4" style="color: #A60321;">Unpublished</span> Fare</h4>
                        <a href="tel:1-855-570-0146"><i class="fa fa-solid fa-phone"></i> 1-855-570-0146</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>

<script src="asset/js/search.js"></script>
<script src="asset/js/jquery-validate.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var colDiv = document.querySelector('.select-date');
        var travellerBlock = document.querySelector('.traveller_block');

        colDiv.addEventListener('click', function() {
            if (travellerBlock.style.display === 'none') {
                travellerBlock.style.display = 'none';
            } else {
                travellerBlock.style.display = 'none';
            }
        });
    });
</script>
<?php wp_footer(); ?>

</body>


</html>