<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php bloginfo('name'); ?> | <?php wp_title(); ?></title>
  <?php wp_head(); ?>
</head>
<style>
		h1 {
			color: #ffffff;
		}

		h3,
		h4,
		h5 {
			font-size: 2rem;
		}

		.block {}
	</style>
	<script type="text/javascript" async>
		$(document).ready(function() {
			$(".block").slice(0, 1).show();
			if ($(".block:hidden").length != 0) {
				$("#load").show();
			}
			$("#load").on("click", function(e) {
				e.preventDefault();
				$(".block:hidden").slice(0, 1).slideDown();
				if ($(".block:hidden").length == 0) {
					$("#load").text("No More")
					$("#load").css({
							"background-color": "#A60321",
							"padding": "10px",
							"text-align": "center",
							"color": "#ffffff",
							"border-radius": "5%",
							"margin-left": "46%"
						})
						.fadOut("slow");
				}
			});
		})



		$(document).ready(function() {
			$(".block1").slice(0, 1).show();
			if ($(".block1:hidden").length != 0) {
				$("#load1").show();
			}
			$("#load1").on("click", function(e) {
				e.preventDefault();
				$(".block1:hidden").slice(0, 1).slideDown();
				if ($(".block1:hidden").length == 0) {
					$("#load1").text("No More")
					$("#load1").css({
							"background-color": "#A60321",
							"padding": "10px",
							"text-align": "center",
							"color": "#ffffff",
							"border-radius": "5%",
							"margin-left": "46%"
						})
						.fadOut("slow");
				}
			});
		})

		$(document).ready(function() {
			$(".block2").slice(0, 1).show();
			if ($(".block2:hidden").length != 0) {
				$("#load2").show();
			}
			$("#load2").on("click", function(e) {
				e.preventDefault();
				$(".block2:hidden").slice(0, 1).slideDown();
				if ($(".block2:hidden").length == 0) {
					$("#load2").text("No More")
					$("#load2").css({
							"background-color": "#A60321",
							"padding": "10px",
							"text-align": "center",
							"color": "#ffffff",
							"border-radius": "5%",
							"margin-left": "46%"
						})
						.fadOut("slow");
				}
			});
		})


		$(document).ready(function() {
			$(".block3").slice(0, 1).show();
			if ($(".block3:hidden").length != 0) {
				$("#load3").show();
			}
			$("#load3").on("click", function(e) {
				e.preventDefault();
				$(".block3:hidden").slice(0, 1).slideDown();
				if ($(".block3:hidden").length == 0) {
					$("#load3").text("No More")
					$("#load3").css({
							"background-color": "#A60321",
							"padding": "10px",
							"text-align": "center",
							"color": "#ffffff",
							"border-radius": "5%",
							"margin-left": "46%"
						})
						.fadOut("slow");
				}
			});
		})
	</script>

	<!-- Google Tag Manager -->
	<script>
		(function(w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				'gtm.start': new Date().getTime(),
				event: 'gtm.js'
			});
			var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s),
				dl = l != 'dataLayer' ? '&l=' + l : '';
			j.async = true;
			j.src =
				'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-MCMMLQXC');
	</script>
	<!-- End Google Tag Manager -->
	<link rel="stylesheet" href="asset/css/search-engine.css">

	<!-- jQuery UI -->
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<style>
		.support a {
			background: #A60321;
			color: #fff;
			font-weight: bold;
			font-size: 25px;
			padding: 10px 20px 10px 20px;
			text-decoration: none;
			border-radius: 50px;
		}
		.ui-autocomplete {
			max-height: 300px;
			max-width: 350px;
			overflow-y: auto;
			/* prevent horizontal scrollbar */
			overflow-x: hidden;
		}

		.support i {
			width: 40px;
			height: 40px;

			border-radius: 50px;
			padding: 9px;
			background-color: black;
			color: white;
		}
	</style>

<body <?php body_class(); ?>>

<header>
        <nav class="navbar navbar-expand-md bg-dark navbar-dark nav-bg">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapsibleNavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <a class="navbar-brand logo-clr"
                    href="https://www.topairlinerules.com/"><img
                        src="https://www.topairlinerules.com/asset/image/Logo.png" alt="Top Airline Rules"
                        class="logo"></a>
                <span class="toll-free d-sm-inline-block d-md-none"><a href="tel:18555700146" style="font-size: 12px;"><span
                            class="bell fa fa-bell"></span> 1-855-570-0146
                    </a></span>

                <div class="collapse navbar-collapse" id="collapsibleNavbar">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link"
                                href="https://www.topairlinerules.com/">Home</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#"
                                role="button"
                                data-bs-toggle="dropdown">Cancellation
                                Policy</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/southwest-airlines-cancellation-policy">Southwest
                                        Airlines Cancellation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/spirit-airlines-cancellation-policy">Spirit
                                        Airlines Cancellation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/united-airlines-cancellation-policy">United
                                        Airlines Cancellation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/volaris-airlines-cancellation-policy">Volaris
                                        Airlines Cancellation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/jetblue-airlines-cancellation-policy">JetBlue
                                        Airlines Cancellation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/hawaiian-airlines-cancellation-policy">Hawaiian
                                        Airlines Cancellation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/delta-airlines-cancellation-policy">Delta
                                        Airlines Cancellation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/alaska-airlines-cancellation-policy">Alaska
                                        Airlines Cancellation Policy</a></li>

                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#"
                                role="button" data-bs-toggle="dropdown">Flight
                                Change</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/alaska-airline-flight-change-policy">Alaska
                                        Airline Flight Change Policy </a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/delta-airline-flight-change-policy">Delta
                                        Airline Flight Change Policy </a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/hawaiian-airlines-flight-change-policy">Hawaiian
                                        Airlines Flight Change Policy </a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/jetblue-airline-flight-change-policy">JetBlue
                                        Airline Flight Change Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/southwest-airlines-flight-change-policy">Southwest
                                        Airlines Flight Change Policy </a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/spirit-airlines-flight-change-policy">Spirit
                                        Airlines Flight Change Policy </a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/united-airlines-flight-change-policy">United
                                        Airlines Flight Change Policy </a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/volaris-airlines-flight-change-policy">Volaris
                                        Airlines Flight Change Policy </a></li>

                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#"
                                role="button" data-bs-toggle="dropdown">Name
                                Change</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/alaska-airlines-name-change-policy">
                                        Alaska Airlines Name Change
                                        Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/delta-airlines-name-change-policy">
                                        Delta Airlines Name Change
                                        Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/hawaiian-airlines-name-change-policy">
                                        Hawaiian Airlines Name Change
                                        Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/jetblue-airlines-name-change-policy">
                                        JetBlue Airlines Name Change
                                        Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/southwest-airlines-name-change-policy">
                                        Southwest Airlines Name Change
                                        Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/spirit-airlines-name-change-policy">
                                        Spirit Airlines Name Change
                                        Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/united-airlines-name-change-policy">
                                        United Airlines Name Change
                                        Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/volaris-airlines-name-change-policy">
                                        Volaris Airlines Name Change
                                        Policy</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#"
                                role="button"
                                data-bs-toggle="dropdown">Reservation Policy</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/alaska-airlines-reservation-policy">Alaska
                                        Airlines Reservation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/delta-airlines-reservation-policy">Delta
                                        Airlines Reservation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/hawaiian-airlines-reservation-policy">Hawaiian
                                        Airlines Reservation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/jetblue-airlines-reservation-policy">JetBlue
                                        Airlines Reservation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/southwest-airlines-reservation-policy">Southwest
                                        Airlines Reservation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/spirit-airlines-reservation-policy">Spirit
                                        Airlines Reservation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/united-airlines-reservation-policy">United
                                        Airlines Reservation Policy</a></li>
                                <li><a class="dropdown-item"
                                        href="https://www.topairlinerules.com/volaris-airlines-reservation-policy">Volaris
                                        Airlines Reservation Policy</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="https://www.topairlinerules.com/blog">Blog</a>
                        </li>

                        <!--<li class="nav-item">
          <a class="nav-link" href="#"><i class="fa fa-phone" aria-hidden="true"></i>1234567890 </a>
        </li>-->
                    </ul>
                </div>
                <span class="toll-free d-none  d-md-inline-block "><a href="tel:18555700146"><span
                            class="bell fa fa-bell"></span> 1-855-570-0146
                    </a></span>

            </div>

        </nav>
    </header>
