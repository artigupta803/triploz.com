$(document).ready(function () {

	var numberOfMonthValue;
	$(window).resize(function () {
		if ($(window).width() < 768) {
			numberOfMonthValue = 1;
			$("#departDate").datepicker("option", "numberOfMonths", numberOfMonthValue);
			$("#returnDate").datepicker("option", "numberOfMonths", numberOfMonthValue);
		} else {
			numberOfMonthValue = 2;
			$("#departDate").datepicker("option", "numberOfMonths", numberOfMonthValue);
			$("#returnDate").datepicker("option", "numberOfMonths", numberOfMonthValue);
		}
	}).trigger('resize');

	var currentDate = new Date();

	$("#departDate").val(currentDate);
	$("#departDate").val($.datepicker.formatDate("mm/dd/yy", currentDate));
	currentDate.setDate(currentDate.getDate() + 7)

	$("#returnDate").val(currentDate);
	$("#returnDate").val($.datepicker.formatDate("mm/dd/yy", currentDate));

	$("input[name='triptype']").click(function () {
		var triptype = $(this).val();
		$("#tripType").val(triptype);

		if (triptype == '1') {
			$("#returnDate").prop("disabled", true); 
			
			$("#returnDiv").hide();
			$("#departDiv").removeClass("col-50");
		}
		else if (triptype == '2') {

			$('#returnDate').val($("#returnDate").val());
			$("#returnDate").prop("disabled", false);
			$("#returnDiv").show();
			$("#departDiv").addClass("col-50");
			$("#returnDate").datepicker("change", {
				minDate: $('#departDate').datepicker("getDate")
			});
		}
	})


	var getData = function (request, response) {
		$.ajax({
			url: "getAirprotList",
			type: 'POST', // Specify POST request
			dataType: "json",
			data: {
				query: request.term
			},
			success: function (data) {
				response(data);
			},
			error: function (xhr, status, error) { // Optional: handle errors
				console.error("Error fetching data:", status, error);
			}
		});
	};

	var selectItem = function (event, ui) {
		$(this).val(ui.item.value);
		
		if (this.id == "origin") {
			setTimeout(function () {
				$("#destination").focus();
			}, 100);
		}
	}

	$("#origin").autocomplete({
		source: getData,
		select: selectItem,
		minLength: 2,
		autoFocus: true
	}).data("ui-autocomplete")._renderItem = function (ul, item) {
		// Customize the display of the items in the dropdown
		return $("<li>")
			.append("<div>" + item.label + "<br>" + item.airport + "</div>")
			.appendTo(ul);
		};

	$("#destination").autocomplete({
		source: getData,
		select: selectItem,
		minLength: 2,
		autoFocus: true
	}).data("ui-autocomplete")._renderItem = function (ul, item) {
		// Customize the display of the items in the dropdown
		return $("<li>")
			.append("<div>" + item.label + "<br>" + item.airport + "</div>")
			.appendTo(ul);
		};

	$(".swap_arow").click(function () {
		$(this).toggleClass("exchange");
		var fromCity = $("#origin").val();
		var toCity = $("#destination").val();
		$("#origin").val(toCity);
		$("#destination").val(fromCity);
	});

	$("#departDate").datepicker({
		dateFormat: "yy-mm-dd",
		minDate: new Date(),
		maxDate: "+11M",
		defaultDate: new Date(),
		//numberOfMonths:2,
		numberOfMonths: numberOfMonthValue,
		beforeShow: function () {
			var xPos = $("#departDate").offset();
			setTimeout(function () {
				$('.ui-datepicker').css({ 'left': xPos.left, 'top': xPos.top + 67 });
			}, 0);
		},
		onSelect: function (date, event) {
			//console.log(date);
			$("#departDate").val($.datepicker.formatDate("yy-mm-dd", new Date(date)));
			$("#returnDate").val($.datepicker.formatDate("yy-mm-dd", new Date(date)));
			$("#returnDate").val(date);
		},
		onClose: function (date) {
			if ($("#tripType").val() == "2") {
				$('#returnDate').datepicker("option", "minDate", new Date(date));
				$('#returnDate').datepicker('show');
			}
		}
	});
	var today = new Date(); // Current date
    $("#departDate").val($.datepicker.formatDate("yy-mm-dd", today));
	$("#returnDate").val($.datepicker.formatDate("yy-mm-dd", today));

	$("#returnDate").datepicker({
		dateFormat: "yy-mm-dd",
		minDate: new Date('yy-mm-dd'),
		maxDate: "+11M",
		numberOfMonths: numberOfMonthValue,
		beforeShow: function () {
			var xPos = $("#departDate").offset();
			//if( $(window).width() > 767 ){
			setTimeout(function () {
				$('.ui-datepicker').css({ 'left': xPos.left, 'top': xPos.top + 67 });
			}, 0);
			//}
		},
		onSelect: function (date, event) {
			$("#returnDate").val($.datepicker.formatDate("yy-mm-dd", new Date(date)));
		}
	});

	$("input[name='classtype']").click(function () {
		var classtype = $(this).val();
		console.log(classtype);
		$("#cabin").val(classtype);
		calculateTravller();
	})

	function calculateTravller() {
		var adult = $("#adult").val();
		var child = $("#child").val();
		var infant = $("#infant").val();
		var infantWs = $("#infantWs").val();
		var totalCount = Number(adult) + Number(child) + Number(infant) + Number(infantWs);
		var classtype = $("#cabin").val();
		$("input[name=classtype][value=" + classtype + "]").prop('checked', true);
		if (classtype == 'PremiumEconomy') {
			classtype = "Premium Economy";
		}
		console.log(classtype);
		if (totalCount == 1)
			$(".traveller").val(totalCount + " Traveler, " + classtype);
		else
			$(".traveller").val(totalCount + " Travelers, " + classtype);
	}

	$(".addicons.minus").click(function () {
		var pax = $(this).data("value");
		var adult = $("#adult").val();
		var child = $("#child").val();
		var infant = $("#infant").val();
		var infantWs = $("#infantWs").val();
		var totalCount = Number(adult) + Number(child) + Number(infant) + Number(infantWs);

		if (pax == 'adult') {
			adult = Number(adult) - 1;
			if (adult > 0)
				$("#adult").val(adult);
			if (infant > adult && adult > 0)
				$("#infant").val(adult);
			if (infantWs > adult && adult > 0)
				$("#infantWs").val(adult);
		}
		else if (pax == 'child') {
			child = Number(child) - 1;
			if (child >= 0)
				$("#child").val(child);
		}
		else if (pax == 'infant') {
			infant = Number(infant) - 1;
			if (infant >= 0)
				$("#infant").val(infant);
		}
		else if (pax == 'infantWs') {
			infantWs = Number(infantWs) - 1;
			if (infantWs >= 0)
				$("#infantWs").val(infantWs);
		}
		$("#error").hide();
		calculateTravller();
	})

	$(".addicons.plus").click(function () {
		var pax = $(this).data("value");
		var adult = $("#adult").val();
		var child = $("#child").val();
		var infant = $("#infant").val();
		var infantWs = $("#infantWs").val();
		var totalCount = Number(adult) + Number(child) + Number(infant) + Number(infantWs);
		if (totalCount < 9) {
			if (pax == 'adult') {
				adult = Number(adult) + 1;
				$("#adult").val(adult);
			}
			else if (pax == 'child') {
				child = Number(child) + 1;
				$("#child").val(child);
			}
			else if (pax == 'infant') {
				infant = Number(infant) + 1;
				if (infant <= adult)
					$("#infant").val(infant);
				else
					$("#error").text("Infant lap can't be greater than adult").show();
			}
			else if (pax == 'infantWs') {
				infantWs = Number(infantWs) + 1;
				if (infantWs <= adult)
					$("#infantWs").val(infantWs);
				else
					$("#error").text("Infant on seat can't be greater than adult").show();
			}
		}
		else {
			$("#error").text("Total traveler can't be greater than 9").show();
		}
		calculateTravller();
	})

	$(".done_button,.searchwindowclose").click(function () {
		$(".traveller_block").hide();
		$(".search_overlay").hide();
		$(".traveller_click").removeClass("activefield");
		calculateTravller();
	});

	$(".traveller_click").click(function () {
		$(".traveller_block").show();
		$(".search_overlay").show();
		$(this).addClass("activefield");
		$("#ui-datepicker-div").hide();
	});

	var formData = $("#flightSearch").serialize();
	function randomString() {
		for (var t = "", e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", n = 0; n < 15; n++) t += e.charAt(Math.floor(Math.random() * e.length));
		return t
	}

	//var randomStr = randomString();
	//$.validator.messages.required = '';
	




	$("#flightSearch").validate({
		rules: {
			origin: {
				required: true
			},
			destination: {
				required: true
			},
			departDate: {
				required: true,
			},
			returnDate: {
				required: true,
			}
		},
		errorPlacement: function (error, element) { },
		submitHandler: function (form) {


			if ($("#origin").val() == $("#destination").val()) {
				alert("From airport & To airport must be different.");
				return false;

			}


			if (formData == $("#flightSearch").serialize()) {
				$(".sameSearch").show();
			}
			else {
			 
				//form.action = '/flight-listing/' + randomStr;
				var from =  $('#origin').val();
				var to =  $('#destination').val();
				var departDate = $('#departDate').val();
				var rtdate = $('#returnDate').val();
				var coachValue = $("input[name='coach']").val();
				$('#address').html(from + ' - ' + to);
				$('#date').html(departDate + ' - ' + rtdate);
				$('#class').html(coachValue);
                 

				$('#flightloader').modal('show')
				
				//form.submit();
				makeAjaxCall(3)
			}
		}
	})

	$("#flightSearch").on('submit', function (event) {
		event.preventDefault();
		$("#flightSearch").validate();
	})


});
function makeAjaxCall(retryCount) {


	$.ajax({
	  url: 'flightfares', // Replace with your API endpoint
	  type: 'post', // The HTTP method (GET, POST, etc.)
	  data: $('#flightSearch').serialize(), // The type of data expected back from the server
	  success: function (response) {
		// Handle the response data
		if (response.trim() == 'Data Retrive') {
		  window.location.href = 'flight-listing';
		}
  
  
	  },
	  error: function (xhr, status, error) {
		if (retryCount > 0) {
		  console.log('Retrying... Attempts left: ' + retryCount);
		  makeAjaxCall(retryCount - 1); // Retry the AJAX call
		} else {
		  console.log('Attempts Expires');
		}
  
	  }
	});
  }


function ValidateEmail(mail) {
	if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(mail)) {
		return true;
	}
	return false;
}

function newsalertsubmit() {
	var newsEmail = $("#subscribeEmail").val();

	if (newsEmail == '') {
		$("#subscribeError").text("Please enter email").css('color', 'red').show();
		$("#subscribeError").delay(5000).fadeOut('slow');
		return false;
	}

	var test = ValidateEmail(newsEmail);
	if (test) {

		$("#spnloader").show();
		$("#subscribeButton").hide();

		var data = { emailId: newsEmail }
		$.ajax({
			url: '/newsletter/submit',
			type: 'post',
			contentType: 'application/json; charset=utf-8',
			data: JSON.stringify(data),
			dataType: "text",
			success: function (response) {
				var newsRes = JSON.parse(response);


				if (newsRes == true) {
					$("#spnloader").hide();
					$("#subscribeButton").show();
					$("#subscribeError").text("You Have Registered Susccessfully!").css("color", "green");
					$("#subscribeEmail").val('');
				}
				else {
					$("#subscribeError").text("Some Technical Issue Please try later!").css("color", "red");
					$("#spnloader").hide();
					$("#subscribeButton").show();
				}
			}
		});
	}
	else {
		$("#subscribeError").text("Please Enter Valid Email").css("color", "red");
	}
	$("#subscribeError").delay(10000).fadeOut('slow');
}

function engineshow() {
	document.getElementsByClassName('fehead')[0].style.display = "none";
	document.getElementsByClassName('flight-engine')[0].style.display = "block";
	document.getElementById('screenoverlay2').style.display = "block";
}

function enginehide() {
	document.getElementsByClassName('fehead')[0].style.display = "flex";
	document.getElementsByClassName('flight-engine')[0].style.display = "none";
	document.getElementById('screenoverlay2').style.display = "none";
}
function filterhide() {
	var filter = document.getElementsByClassName('filter')[0];
	var fabtn = document.getElementsByClassName('fapply')[0];
	filter.style.height = '0';
	fabtn.style.height = '0';
}
function filtershow() {
	alert("Hi");
	var filter = document.getElementsByClassName('filter')[0];
	var fabtn = document.getElementsByClassName('fapply')[0];
	filter.style.height = '100vh';
	fabtn.style.height = '45px';
}
function ftype(t, n) {
	var container = document.getElementsByClassName('filter-item');
	var type = document.getElementsByClassName('ftype');
	for (i = 0; i < container.length; i++) {
		container[i].style.visibility = 'hidden';
	}
	for (j = 0; j < type.length; j++) {
		type[j].setAttribute('class', 'ftype');
	}
	t.style.visibility = 'visible';
	type[parseInt(n)].setAttribute('class', 'ftype filtertypeactive')
}

function ShowAirlinesSearchMobile(button, froCity, toCityName, fromDate, toDate) {
	//alert("froCity - "+froCity+" toCityName - "+toCityName+" fromDate - "+ fromDate+" toDate - "+toDate);/

	$("#origin").val(froCity);
	$("#destination").val(toCityName);
	$("#departDate").val(fromDate);
	$("#returnDate").val(toDate);
	$("#adult").val(1);
	$("#child").val(0);
	$("#infant").val(0);
	$("#infantWs").val(0);
	$("#classtype").val("Economy");
	$("#flightSearch").submit();
}